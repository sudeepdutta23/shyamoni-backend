<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_table', function (Blueprint $table) {

            $table->uuid('id');
            $table->integer('cate_id')->nullable();
            $table->integer('subCate_id')->nullable();
            $table->string('productName')->nullable();
            $table->string('brand')->nullable();
            $table->float('quantity')->nullable();
            $table->float('orginal_price')->nullable();
            $table->float('selling_price')->nullable();
            $table->float('discount_amount')->nullable();
            $table->string('shortDesc')->nullable();
            $table->string('longDesc')->nullable();
            $table->string('keywords')->nullable();
            $table->integer('status')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_masters');
    }
};
